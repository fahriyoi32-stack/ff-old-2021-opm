# FF OLD 2021 — proyek Android

Ini adalah **demo lobi nostalgia buatan penggemar**, bukan game Free Fire resmi. Tidak ada pertandingan online atau koneksi ke server Garena. Menu hanya simulasi tampilan.

## Cara paling mudah membuat APK (tanpa memasang Android Studio)

Karena lingkungan pembuat file ini tidak memiliki Android SDK/Gradle dan tidak bisa mengunduh build tools, APK belum bisa dikompilasi langsung di sini. Proyek ini sudah disiapkan dengan workflow build otomatis.

1. Di HP, buka GitHub dan masuk akun (atau buat akun gratis).
2. Buat repository baru bernama `ff-old-2021`. Pilih **Public** atau **Private**, lalu buat repository.
3. Di repository, pilih **Add file → Upload files**.
4. Ekstrak ZIP proyek ini terlebih dahulu. Upload seluruh isi folder proyek (termasuk folder `.github` yang berisi workflow) ke repository, lalu tekan **Commit changes**.
5. Buka tab **Actions** pada repository. Pilih workflow **Build FF OLD 2021 APK**.
6. Tekan **Run workflow** jika belum berjalan otomatis, lalu tunggu sampai status berwarna hijau.
7. Buka hasil proses tersebut dan cari bagian **Artifacts**. Unduh `FF-OLD-2021-APK.zip`, lalu ekstrak. Di dalamnya ada `app-debug.apk`.
8. Buka APK di HP untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk aplikasi yang kamu pakai mengunduh file.

## Jika upload lewat HP
Pastikan file/folder `.github/workflows/build-apk.yml` ikut ter-upload. Workflow tersebut yang membuat APK otomatis.

## Kompatibilitas
- Minimum Android disetel API 23 (Android 6.0).
- Target SDK 28 agar lebih luas untuk perangkat lama; kompatibilitas tetap perlu diuji di perangkat nyata.
- APK debug ditandatangani otomatis untuk pengujian. APK ini bukan rilisan resmi.
