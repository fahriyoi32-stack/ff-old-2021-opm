package com.dexri.ffold2021;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(9,13,20));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,13,20));
    WebView web = new WebView(this);
    web.setBackgroundColor(android.graphics.Color.rgb(9,13,20));
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(false);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(false);
    web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    web.loadUrl("file:///android_asset/index.html");
    setContentView(web);
  }
}
